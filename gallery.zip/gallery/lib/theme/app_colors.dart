import 'package:flutter/material.dart';

class AppColors {
  static const Color appColor = Color(0xFF4CAF50); // Example color, can be updated
}