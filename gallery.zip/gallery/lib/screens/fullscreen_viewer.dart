import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';

class FullScreenImageViewer extends StatelessWidget {
  final AssetEntity asset;

  const FullScreenImageViewer({super.key, required this.asset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: FutureBuilder<Widget>(
          future: asset.originWidget(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
              return snapshot.data!;
            }
            return const CircularProgressIndicator();
          },
        ),
      ),
    );
  }
}

extension on AssetEntity {
  originWidget() {}
}
