import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:gallery/theme/app_colors.dart'; // Import your colors
import 'fullscreen_viewer.dart'; // Import the fullscreen viewer

class GalleryScreen extends StatefulWidget {
  @override
  _GalleryScreenState createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<AssetEntity> _assets = [];

  // Load images from the gallery
  Future<void> loadImages() async {
    final permission = await Permission.photos.request();
    if (permission.isGranted) {
      // Get images from the device
      final albums = await PhotoManager.getAssetPathList(onlyAll: true);
      final assetPath = albums.first;
      final assets = await assetPath.getAssetListPaged(
        page: 0,
        size: 100,
      ); // Load first 100 images
      setState(() {
        _assets = assets;
      });
    } else {
      print("Permission Denied");
    }
  }

  @override
  void initState() {
    super.initState();
    loadImages();  // Call the function to load images when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'My Gallery',
            style: TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: AppColors.appColor,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,  // 3 images per row
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
        ),
        itemCount: _assets.length,
        itemBuilder: (context, index) {
          final asset = _assets[index];
          return GestureDetector(
            onTap: () {
              // Navigate to fullscreen viewer
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => FullScreenImageViewer(asset: asset),
                ),
              );
            },
            child: FutureBuilder<Widget>(
              future: asset.thumbnailWidget(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: snapshot.data?.image as ImageProvider,
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                }
                return Center(child: CircularProgressIndicator());
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Handle add image or other functionality
        },
        child: Icon(Icons.add),
        backgroundColor: AppColors.appColor,
        foregroundColor: Colors.white,
      ),
    );
  }
}

extension on Widget? {
  get image => null;
}

extension on AssetEntity {
  thumbnailWidget() {}
}